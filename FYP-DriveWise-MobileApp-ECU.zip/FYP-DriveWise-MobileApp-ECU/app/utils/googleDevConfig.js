import { GOOGLE_MAPS_API_KEY} from '@env';

export const googDevConf = {
  key: GOOGLE_MAPS_API_KEY
};
